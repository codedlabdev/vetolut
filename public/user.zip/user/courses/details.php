<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// At the top of the file, after session_start()
// Add this before including other files
$_SERVER['SCRIPT_NAME'] = str_replace('?' . $_SERVER['QUERY_STRING'], '', $_SERVER['REQUEST_URI']);

// Include files using absolute paths
include '../inc/p_top.php';
require_once BASE_DIR . 'lib/user/case_lists.php';
require_once BASE_DIR . 'lib/user/courses_func.php';

// Rest of your code remains the same...
// Get the complete URL including query parameters
/*$current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$query_string = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
$full_url = $current_path . ($query_string ? '?' . $query_string : '');

// Debug section
echo '<div style="background: #f8f9fa; padding: 10px; margin: 10px; border: 1px solid #ddd;">';
echo '<h4>Debug Information:</h4>';
echo 'Session Status: ' . session_status() . '<br>';
echo 'Session ID: ' . session_id() . '<br>';
if (isset($_SESSION['user_id'])) {
    echo 'User ID: ' . $_SESSION['user_id'] . '<br>';
}
echo 'Current Path: ' . $full_url . '<br>';
echo '</div>';
*/
// Get course ID from URL parameter
$course_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch course details
$course = getCourseDetails($course_id); // Changed from get_course_details to getCourseDetails

// Redirect if course doesn't exist
if (!$course) {  // The function already checks status and admin_status
    header('Location: ' . BASE_URL . 'public/user/courses/main.php');
    exit;
}

// Continue with the rest of the page if course exists
?>

<link href="<?php echo BASE_URL; ?>public/user/courses/main.css" rel="stylesheet">
<link href="<?php echo BASE_URL; ?>public/user/courses/details.css" rel="stylesheet">

<!-- Remove all <style> tags and their contents from the file -->
<div class="container mt-4">
    <!-- Course Header Section -->
    <div class="row">
        <div class="col-lg-8">
            <!-- Course Preview Section -->
            <div class="course-preview position-relative mb-4">
                <div class="preview-image position-relative">
                    <div class="video-container" style="display: none;">
                        <video id="previewVideo" class="w-100" controls>
                            <source src="<?php echo BASE_URL . $course['intro_video']; ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    </div>
                    <div class="banner-container">
                        <img src="<?php echo !empty($course['banner_image']) ? BASE_URL . $course['banner_image'] : 'https://placehold.co/600x400'; ?>" class="img-fluid w-100" alt="<?php echo htmlspecialchars($course['title']); ?>">
                        <?php if (!empty($course['intro_video'])): ?>
                            <div class="play-button-overlay position-absolute top-50 start-50 translate-middle">
                                <button class="btn btn-light rounded-circle p-3" id="playButton">
                                    <i class="fas fa-play fs-4"></i>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Video Preview Modal -->
    <div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="previewModalLabel"><?php echo htmlspecialchars($course['title']); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-0">
                    <video id="previewVideo" class="w-100" controls>
                        <source src="<?php echo BASE_URL . $course['intro_video']; ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <div>
        <div>
            <h1 class="course-title pe-5"><?php echo htmlspecialchars($course['title']); ?></h1>
            <div class="course-meta pe-3">
                <span class="h3 fw-bold mb-0">
                    <?php echo ($course['price'] == 0) ? 'Free' : '$' . number_format($course['price'], 2); ?>
                </span>
            </div>
        </div>

        <div class="d-flex align-items-center justify-content-between mt-2">
            <div class="d-flex align-items-center">
                <div class="rating me-2">
                    <i class="fas fa-star text-warning"></i>
                    <span class="ms-1 fw-bold">4.5</span>
                </div>
            </div>

        </div>

        <div class="instructor-info d-flex align-items-center mt-3">
            <img src="<?php echo !empty($course['instructor_image']) ? $course['instructor_image'] : 'assets/user/img/noimage.png'; ?>" class="rounded-circle" alt="<?php echo htmlspecialchars($course['instructor_name']); ?>" width="50" height="50">
            <div class="ms-3">
                <p class="mb-0" style="font-size: large;"><?php echo htmlspecialchars($course['instructor_name']); ?></p>
                <span class="ms-1" style="font-size: large;"><small><?php echo htmlspecialchars($course['instructor_profession']); ?></small></span>
            </div>

            <button class="btn btn-primary px-4 py-2" style="right: 20px;position: absolute;">
                <i class="fas fa-shopping-cart me-2"></i>
                <?php echo ($course['price'] == 0) ? 'Enroll Now' : 'Buy Now'; ?>
            </button>

        </div>

    </div>
</div>

</div>
</div>
<!-- Course Navigation -->
<div class="container">
    <div class="course-navigation">
        <ul class="nav nav-tabs nav-fill" id="courseTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active text-uppercase position-relative" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button" role="tab">
                    Overview
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-uppercase position-relative" id="lessons-tab" data-bs-toggle="tab" data-bs-target="#lessons" type="button" role="tab">
                    Lessons
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-uppercase position-relative" id="review-tab" data-bs-toggle="tab" data-bs-target="#review" type="button" role="tab">
                    Review
                </button>
            </li>
        </ul>
    </div>
</div>






<!-- Tab Content Sections -->
<div class="container">
    <div class="tab-content p-4" id="courseTabContent">
        <!-- Overview Tab -->
        <div class="tab-pane fade show active" id="overview" role="tabpanel">
            <div class="row">
                <div class="col-lg-8">
                    <div class="course-description rounded p-4 mb-4">
                        <h4 class="mb-4 border-bottom pb-2">Description</h4>
                        <div class="description-content">
                            <p>
                                <?php
                                if (!empty($course['description'])) {
                                    echo htmlspecialchars($course['description']);
                                } else {
                                    echo 'No description available.';
                                }
                                ?>
                            </p>
                        </div>
                    </div>
                    </<link rel="pingback" href="xmlrpc.php" />




                </div>
            </div>
        </div>

        <!-- Lessons Tab -->
        <div class="tab-pane fade" id="lessons" role="tabpanel">
            <div class="row">
                <div class="col-lg-8">
                    <div class="lessons-list">
                        <?php
                        $sections = getCourseSections($course_id);
                        if (!empty($sections)):
                            foreach ($sections as $section):
                        ?>
                                <div class="lesson-section mb-3">
                                    <div class="lesson-section-header d-flex justify-content-between align-items-center p-3" data-bs-toggle="collapse" href="#section<?php echo $section['id']; ?>">
                                        <span class="fw-bold">Sections</span>
                                        <i class="fas fa-chevron-up"></i>
                                    </div>
                                    <div id="section<?php echo $section['id']; ?>" class="collapse show">
                                        <div class="lesson">
                                            <div class="d-flex align-items-start w-100">
                                                <div class="lesson-content flex-grow-1">
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <h5 class="lesson-title mb-2"><?php echo htmlspecialchars($section['title']); ?></h5>

                                                        <i class="fas fa-lock text-muted"></i>

                                                    </div>
                                                    <p class="lesson-description mb-2"><?php echo substr(htmlspecialchars($section['description']), 0, 150); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            endforeach;
                        else:
                            ?>
                            <div class="alert alert-info">
                                No sections available for this course yet.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Review Tab -->
        <!-- Review Tab -->
        <div class="tab-pane fade" id="review" role="tabpanel">
            <div class="row">
                <div class="col-lg-8">
                    <div class="review-summary mb-4">
                        <h4>Student Reviews</h4>
                        <div class="d-flex align-items-center">
                            <div class="display-4 fw-bold me-3">4.5</div>
                            <div class="stars">
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star-half-alt text-warning"></i>
                                <div class="text-muted mt-1">Based on 1233 reviews</div>
                            </div>
                        </div>
                    </div>

                    <!-- Review Cards -->
                    <div class="review-cards">
                        <div class="review-card mb-4">
                            <div class="d-flex align-items-start">
                                <img src="https://placehold.co/60x60" class="rounded-circle me-3" width="60" height="60" style="object-fit: cover;" alt="Jimy Oslin">
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h6 class="mb-0">Jimy Oslin</h6>
                                        <div class="stars">
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                        </div>
                                    </div>
                                    <small class="text-muted d-block mb-2">A day ago</small>
                                    <p class="mb-0">Nostrud excepteur magna id est quis in aliqua consequat. L'exercitation enim eiusmod elit sint laborum</p>
                                </div>
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
</div>


<script>
    $(document).ready(function() {
        $('.lesson-section-header').on('click', function() {
            const icon = $(this).find('i.fas');
            if (icon.hasClass('fa-chevron-up')) {
                icon.removeClass('fa-chevron-up').addClass('fa-chevron-down');
            } else {
                icon.removeClass('fa-chevron-down').addClass('fa-chevron-up');
            }
        });

        // Update the radio button change handler
        $('input[name="card"]').on('change', function() {
            const cardDetails = $("#cardDetails");
            const paypalButton = $("#paypalButton");
            const processPaymentBtn = $("#processPayment");

            if ($(this).val() === 'mastercard') {
                cardDetails.addClass('active');
                paypalButton.removeClass('active');
                processPaymentBtn.show(); // Show process payment button for mastercard
            } else {
                cardDetails.removeClass('active');
                paypalButton.addClass('active');
                processPaymentBtn.hide(); // Hide process payment button for paypal
            }
        });

        // Enable PayPal button when terms are accepted
        $('#paypalTerms').on('change', function() {
            $('#paypalPayButton').prop('disabled', !this.checked);
        });
    });
</script>
<style>
    .tab-content {

        margin-bottom: 120px;
    }

    .fab-button {
        background: #003366 !important;
    }
</style>
<script>
    $(document).ready(function() {
        // Find the "Buy Now" button and add click handler
        $('.btn-primary').on('click', function() {
            $('#paymentModal').modal('show');
        });

        // Add click handlers for payment method radio buttons
        $('input[name="card"]').on('change', function() {
            const cardDetails = $("#cardDetails");
            const paypalButton = $("#paypalButton");

            if ($(this).val() === 'mastercard') {
                cardDetails.addClass('active');
                paypalButton.removeClass('active');
            } else {
                cardDetails.removeClass('active');
                paypalButton.addClass('active');
            }
        });

        $('#processPayment').on('click', function() {
            const cardholder = $("#cardholder").val();
            const cardnumber = $("#cardnumber").val();
            const validuntil = $("#validuntil").val();
            const securitycode = $("#securitycode").val();
            const terms = $("#terms").prop('checked');

            if ($("#mastercard").prop('checked')) {
                if (cardholder && cardnumber && validuntil && securitycode && terms) {
                    // Here you would typically make an AJAX call to your payment processor
                    alert("Processing payment...");
                    $('#paymentModal').modal('hide');
                } else {
                    alert("Please fill in all fields and accept the terms.");
                }
            }
        });
    });

    function payWithPayPal() {
        alert("Redirecting to PayPal for payment...");
        // Add PayPal integration code here
    }
</script>
<?php
include '../inc/float_nav.php';

?>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentModalLabel">Payment Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card-selection">
                    <label>Select card:</label><br />
                    <div class="card-options">
                        <input type="radio" id="mastercard" name="card" value="mastercard" onclick="togglePaymentMethod()" checked />
                        <label for="mastercard">
                            <img src="<?php echo BASE_URL; ?>assets/img/payment/master.jpg" alt="MasterCard" />
                        </label>
                        <input type="radio" id="paypal" name="card" value="paypal" onclick="togglePaymentMethod()" />
                        <label for="paypal">
                            <img src="<?php echo BASE_URL; ?>assets/img/payment/paypal.png" alt="PayPal" />
                        </label>
                    </div>
                </div>
                <div class="card-details active" id="cardDetails">
                    <label for="cardholder">Card holder:</label>
                    <input type="text" id="cardholder" name="cardholder" placeholder="Your name" class="form-control" />

                    <label for="cardnumber">Card number:</label>
                    <input type="text" id="cardnumber" name="cardnumber" placeholder="1234 5678 9012 3456" class="form-control" />

                    <div class="expiration">
                        <div class="row">
                            <div class="col-6">
                                <label for="validuntil">Valid until:</label>
                                <input type="text" id="validuntil" name="validuntil" placeholder="MM/YYYY" class="form-control" />
                            </div>
                            <div class="col-6">
                                <label for="securitycode">Security code:</label>
                                <input type="text" id="securitycode" name="securitycode" placeholder="123" class="form-control" />
                            </div>
                        </div>
                    </div>

                    <div class="terms mt-3">
                        <input type="checkbox" id="terms" checked name="terms" />
                        <label for="terms">Accept the <a href="#">Terms and Conditions</a></label>
                    </div>


                </div>
                <div class="paypal-button" id="paypalButton">
                    <div class="terms mt-3 mb-3">
                        <input type="checkbox" id="paypalTerms" name="paypalTerms" />
                        <label for="paypalTerms">Accept the <a href="#">Terms and Conditions</a></label>
                    </div>
                    <button class="btn btn-primary w-100" onclick="payWithPayPal()" id="paypalPayButton" disabled>Pay with PayPal</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="processPayment">Process Payment</button>
            </div>
        </div>
    </div>
</div>

<!-- Add this CSS -->
<style>
    .card-options {
        display: flex;
        gap: 20px;
        padding: 20px;
        justify-content: center;
    }

    .card-options img {
        width: 100px;
        height: 60px;
        object-fit: contain;
    }

    .card-options input {
        display: none;
    }

    .card-options label {
        cursor: pointer;
        border: 2px solid transparent;
        padding: 5px;
        border-radius: 8px;
    }

    .card-options input:checked+label {
        border: 2px solid #007bff;
    }

    .card-details,
    .paypal-button {
        display: none;
    }

    .card-details.active,
    .paypal-button.active {
        display: block;
    }

    .expiration {
        margin: 15px 0;
    }

    .terms,
    .default-payment {
        margin-bottom: 10px;
    }

    .btn:disabled {
        opacity: 0.65;
        cursor: not-allowed;
    }

    .terms input[type="checkbox"] {
        margin-right: 5px;
    }

    .terms label {
        user-select: none;
    }
</style>

<!-- Add this JavaScript -->
<script>
    // Update the button click handler
    $(document).ready(function() {
        // Find the "Buy Now" button and add click handler
        $('.btn-primary').on('click', function() {
            $('#paymentModal').modal('show');
        });

        function togglePaymentMethod() {
            const cardDetails = document.getElementById("cardDetails");
            const paypalButton = document.getElementById("paypalButton");
            const mastercard = document.getElementById("mastercard");

            if (mastercard.checked) {
                cardDetails.classList.add("active");
                paypalButton.classList.remove("active");
            } else {
                cardDetails.classList.remove("active");
                paypalButton.classList.add("active");
            }
        }

        $('#processPayment').on('click', function() {
            const cardholder = $("#cardholder").val();
            const cardnumber = $("#cardnumber").val();
            const validuntil = $("#validuntil").val();
            const securitycode = $("#securitycode").val();
            const terms = $("#terms").prop('checked');

            if ($("#mastercard").prop('checked')) {
                if (cardholder && cardnumber && validuntil && securitycode && terms) {
                    // Here you would typically make an AJAX call to your payment processor
                    alert("Processing payment...");
                    $('#paymentModal').modal('hide');
                } else {
                    alert("Please fill in all fields and accept the terms.");
                }
            }
        });
    });

    function payWithPayPal() {
        alert("Redirecting to PayPal for payment...");
        // Add PayPal integration code here
    }
</script>

<script>
    $(document).ready(function() {
        // Add terms checkbox handlers for both payment methods
        $("#terms, #paypalTerms").on('change', function() {
            const isMastercard = $("#mastercard").prop('checked');
            const processPaymentBtn = $("#processPayment");
            const paypalPayBtn = $("#paypalPayButton");

            if (isMastercard) {
                processPaymentBtn.prop('disabled', !$("#terms").prop('checked'));
            } else {
                paypalPayBtn.prop('disabled', !$("#paypalTerms").prop('checked'));
            }
        });

        // Update the payment method toggle handler
        $('input[name="card"]').on('change', function() {
            const cardDetails = $("#cardDetails");
            const paypalButton = $("#paypalButton");
            const processPaymentBtn = $("#processPayment");
            const isMastercard = $(this).val() === 'mastercard';

            if (isMastercard) {
                cardDetails.addClass('active');
                paypalButton.removeClass('active');
                processPaymentBtn.show();
                processPaymentBtn.prop('disabled', !$("#terms").prop('checked'));
            } else {
                cardDetails.removeClass('active');
                paypalButton.addClass('active');
                processPaymentBtn.hide();
                $("#paypalPayButton").prop('disabled', !$("#paypalTerms").prop('checked'));
            }
        });

        // Initialize the process payment button state
        $("#processPayment").prop('disabled', !$("#terms").prop('checked'));
    });

    function payWithPayPal() {
        if ($("#paypalTerms").prop('checked')) {
            alert("Redirecting to PayPal for payment...");
            // Add PayPal integration code here
        } else {
            alert("Please accept the terms and conditions");
        }
    }
</script>